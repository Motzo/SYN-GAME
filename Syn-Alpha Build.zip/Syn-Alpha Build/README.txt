Created by Syntax Error


To play, download the entire folder, and run the Syn.exe file.

Controls:

A and D/leftKey and rightKey: left and right movement
W/upKey: jump and double jump
S/downKey: slide in current direction while on ground
Left Shift: run
Space: fire